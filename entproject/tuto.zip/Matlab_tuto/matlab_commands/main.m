clear;

%%%% 1. Variables and functions

x=0;
x= x+1;
a= 1;
b= 2;
c= add(a,b); % No confusion with the local x in add.m !
d= add_mult(a,b); % Only the first output of add_mult is stored in d.
[e,f]= add_mult(a,b);
[~,g]= add_mult(a,b); % First output is not stored in a variable.

addpath auxiliary_functions % Functions in folder "auxiliary_functions" can also be used

global z;
z= 100;
add_global(5);

%%%% 2. Arrays

h= [1 2 3 4 5]; % Row vector
i= [1; 2; 3; 4; 5]; % Column vector
j= [1 2 3 4; 5 6 7 8]; % Matrix

k= h(2); % Index numbering starts at 1
l= i(3);
m= j(1,2);
n= j;
n(1,1)= 10;

% Useful functions

% zeros(2,3)
% zeros(5)
% ones(2,3)
% ones(5)
% eye(6) % Identity function
% length(h) % Length of row/column vector
% length(i)
% size(j) % Dimension of a matrix
% size(j,1)
% size(j,2)

% j(:,3)
% j(1,:)
% j(1,2:4)

o= [eye(2) eye(2) zeros(2,8)];
p= [zeros(2) eye(2); eye(2) zeros(2)];

q= 1:10; % Row vectors
r= -10:2:10;
s= 6:-1:2;

t= j'; % Transposition

%%%% 3. Loops 

% for u=1:10
%     disp(u);
% end
% 
% for u=10:-1:1
%     disp(u);
% end

% v= 10;
% if v==10
%     disp('v = 10');
% elseif v>10
%     disp('v > 10');
% else
%     disp('v<10');
% end

%%%% 4. Debugging

% Display function: disp
% Breakpoints
% Error messages in the command window or in the code
% Warnings.

%%%%% 5. Optimization

% Linear problem: https://fr.mathworks.com/help/optim/ug/linprog.html
% Nonlinear problem: https://fr.mathworks.com/help/optim/ug/fmincon.html

fun = @(x)100*(x(2)-x(1)^2)^2 + (1-x(1))^2;
x0 = [-1,2];
A = [1,2];
b = 1;
x = fmincon(fun,x0,A,b)