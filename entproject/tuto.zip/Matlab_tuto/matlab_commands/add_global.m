function v = add_global(y)

global z;
v= y+z;

end

