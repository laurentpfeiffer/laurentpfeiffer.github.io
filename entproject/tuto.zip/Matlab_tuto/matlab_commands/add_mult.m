function [z_1, z_2] = add_mult(x,y)

z_1= x+y;
z_2= x*y;

end

